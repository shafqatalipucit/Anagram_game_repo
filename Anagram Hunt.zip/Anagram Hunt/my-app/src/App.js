import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

import Main from './Website Content/Main';
import Footer from './Website Content/Footer';
import MainBody from './Website Content/MainBody';
import Login from './Website Content/Login';
import LoginForm from './Website Content/LoginForm';
import Signup from './Website Content/Signup';
import SignupForm from './Website Content/SignupForm';
import About from './Website Content/About';
import AboutContent from './Website Content/AboutContent';
import Contact from './Website Content/Contact';
import ContactUs from './Website Content/ContactUs';
import StartPage from './Website Content/StartPage';
import PlayPage from './Website Content/PlayPage';
import EndPage from './Website Content/EndPage';  
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Main />} />
        <Route path="/footer" element={<Footer />} />
        <Route path="/mainbody" element={<MainBody />} />
        <Route path="/login" element={<Login />} />
        <Route path="/loginform" element={<LoginForm />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/signupform" element={<SignupForm />} />
        <Route path="/about" element={<About />} />
        <Route path="/aboutcontent" element={<AboutContent />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/contactus" element={<ContactUs />} />
        <Route path="/startpage" element={<StartPage />} />
        <Route path="/playpage" element={<PlayPage />} />
        <Route path="/endpage" element={<EndPage />} />  
      </Routes>
    </Router>
  );
}

export default App;
