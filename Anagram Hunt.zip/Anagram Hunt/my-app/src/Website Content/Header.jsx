import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

function Header() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-light shadow-sm">
      <div className="container">
        <a className="navbar-brand text-danger btn btn-outline-dark" href="/">Play2Learn Logo</a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <a className="nav-link text-dark btn btn-light " href="/">Home</a>
            </li>
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle text-dark btn btn-danger" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Games
              </a>
              <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a className="dropdown-item btn btn-outline-dark" href="/StartPage">Anagram Hunt</a></li>
                <li><a className="dropdown-item btn btn-danger" href="#">Math-facts</a></li>
              </ul>
            </li>
            <li className="nav-item">
              <a className="nav-link text-dark btn btn-light" href="/About">About</a>
            </li>
            <li className="nav-item">
              <a className="nav-link text-dark btn btn-light" href="/ContactUs">ContactUs</a>
            </li>
            <li className="nav-item">
              <a className="nav-link text-dark btn btn-danger   " href="/LoginForm">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Header;
