import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function AboutContent() {
    return (
        <div className="main-content">
            <div className="container">
                <div className="content">
                    <h1>About Us</h1>
                    <p className="lead">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium quod dicta non sequi a facilis nisi debitis aliquid quas, dolores sapiente soluta tenetur expedita repudiandae cum iure aspernatur ipsam odio? Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium quod dicta non sequi a facilis nisi debitis aliquid quas, dolores sapiente soluta tenetur expedita repudiandae cum iure aspernatur ipsam odio? Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium quod dicta non sequi a facilis nisi debitis aliquid quas, dolores sapiente soluta tenetur expedita repudiandae cum iure aspernatur ipsam odio? Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium quod dicta non sequi a facilis nisi debitis aliquid quas, dolores sapiente soluta tenetur expedita repudiandae cum iure aspernatur ipsam odio? Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium quod dicta non sequi a facilis nisi debitis aliquid quas, dolores sapiente soluta tenetur expedita repudiandae cum iure aspernatur ipsam odio? Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium quod dicta non sequi a facilis nisi debitis aliquid quas, dolores sapiente soluta tenetur expedita repudiandae cum iure aspernatur ipsam odio? Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium quod dicta non sequi a facilis nisi debitis aliquid quas, dolores sapiente soluta tenetur expedita repudiandae cum iure aspernatur ipsam odio?
                    </p>
                </div>
            </div>
        </div>
    );
}

export default AboutContent;
