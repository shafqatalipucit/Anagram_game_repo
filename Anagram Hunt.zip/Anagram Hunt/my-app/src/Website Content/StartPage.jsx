import React, { useState } from 'react';
import { Container, Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function StartPage() {
  const [wordLength, setWordLength] = useState(3);
  const navigate = useNavigate();

  const handleStartGame = () => {
    console.log(`Navigating to /playpage?length=${wordLength}`);
    navigate(`/playpage?length=${wordLength}`);
  };

  return (
    <Container className="py-5 text-center">
      <h2>Anagram Hunt</h2>
      <Form>
        <Form.Group controlId="wordLength">
          <Form.Label>Select Word Length:</Form.Label>
          <Form.Control
            as="select"
            value={wordLength}
            onChange={(e) => setWordLength(parseInt(e.target.value))}
          >
            {[3, 4, 5, 6, 7, 8, 9, 10].map(length => (
              <option key={length} value={length}>{length}</option>
            ))}
          </Form.Control>
        </Form.Group>
        <Button variant="primary" onClick={handleStartGame}>
          Play!
        </Button>
      </Form>
    </Container>
  );
}

export default StartPage;
