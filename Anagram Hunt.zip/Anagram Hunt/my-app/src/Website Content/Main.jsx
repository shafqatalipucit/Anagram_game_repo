import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './Header';
import Footer from './Footer';
import MainBody from './MainBody';

function Main() {
  return (
    <div >
    <Header/>
    {<MainBody/>}
      <Footer/>
    </div>
  );
}

export default Main;
