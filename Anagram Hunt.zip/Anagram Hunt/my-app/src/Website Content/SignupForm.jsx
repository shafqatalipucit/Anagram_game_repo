import React from 'react'
import Header from './Header'
import Signup from './Signup'
import Footer from './Footer'

function SignupForm() {
  return (
    <div>
      <Header/>
      <Signup/>
      <Footer/>
    </div>
  )
}

export default SignupForm
