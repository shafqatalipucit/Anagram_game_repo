import React from 'react';

const Signup = () => {
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log('Signing up...');
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card shadow-sm">
            <div className="card-body">
              <h2 className="text-center mb-4">Sign Up</h2>
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="signupEmail">Email address</label>
                  <input type="email" className="form-control" id="signupEmail" aria-describedby="emailHelp" placeholder="Enter email" required />
                </div>
                <div className="form-group">
                  <label htmlFor="signupPassword">Password</label>
                  <input type="password" className="form-control" id="signupPassword" placeholder="Password" required />
                </div>
                <div className="form-group">
                  <label htmlFor="signupPasswordRepeat">Repeat Password</label>
                  <input type="password" className="form-control" id="signupPasswordRepeat" placeholder="Repeat Password" required />
                </div>
                <div className="form-group form-check">
                  <input type="checkbox" className="form-check-input" id="agreeTerms" required />
                  <label className="form-check-label" htmlFor="agreeTerms">I agree to the terms and conditions</label>
                </div>
                <button type="submit" className="btn btn-primary btn-block">Sign Up</button>
              </form>
              <p className="text-center mt-3">
                Already have an account? <a href="Loginform">Log in</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
