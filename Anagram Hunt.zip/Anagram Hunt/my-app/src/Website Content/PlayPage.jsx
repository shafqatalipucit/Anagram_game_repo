import React, { useState, useEffect } from 'react';
import { Container, Form, Button, Alert } from 'react-bootstrap';
import { useLocation, useNavigate } from 'react-router-dom';

const anagrams = {
  3: ['cat', 'act', 'bat', 'tab'],
  4: ['star', 'rats', 'arts', 'tars'],
  5: ['beard', 'bread', 'bared', 'debar'],
  6: ['listen', 'silent', 'enlist', 'inlets'],
  7: ['postage', 'stopage', 'potages', 'gestapo'],
  8: ['despair', 'diapers', 'aspired', 'praised'],
  9: ['predator', 'adopters', 'readopts', 'proteads'],
  10: ['resistance', 'nescient', 'centuries', 'secretion'],
};

function PlayPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const wordLength = parseInt(queryParams.get('length'));

  console.log(`Word length from query params: ${wordLength}`);

  const [gameStarted, setGameStarted] = useState(false);
  const [currentWord, setCurrentWord] = useState('');
  const [anagramsLeft, setAnagramsLeft] = useState([]);
  const [score, setScore] = useState(0);
  const [inputValue, setInputValue] = useState('');
  const [correctAnswers, setCorrectAnswers] = useState([]);
  const [message, setMessage] = useState('');
  const [timeLeft, setTimeLeft] = useState(60);
  const [gameOver, setGameOver] = useState(false);

  useEffect(() => {
    if (!gameStarted) return;

    const countdown = setInterval(() => {
      setTimeLeft(prevTime => {
        if (prevTime <= 1) {
          clearInterval(countdown);
          setGameOver(true);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(countdown);
  }, [gameStarted]);

  useEffect(() => {
    if (gameStarted && !gameOver) {
      startNewRound(wordLength);
    }
  }, [gameStarted, gameOver, wordLength]);

  const startNewRound = (length) => {
    if (length in anagrams) {
      const possibleWords = anagrams[length];
      const randomIndex = Math.floor(Math.random() * possibleWords.length);
      const selectedWord = possibleWords[randomIndex];
      setCurrentWord(selectedWord);
      setAnagramsLeft(possibleWords.filter(word => word !== selectedWord));
      setCorrectAnswers([]);
      setScore(0);
      setTimeLeft(60);
      setGameStarted(true);
    }
  };

  useEffect(() => {
    if (!gameStarted) {
      startNewRound(wordLength);
    }
  }, [wordLength]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const guess = inputValue.trim().toLowerCase();

    if (guess === currentWord.toLowerCase()) {
      setMessage('You cannot guess the word itself.');
      setTimeout(() => setMessage(''), 2000);
      return;
    }

    if (correctAnswers.includes(guess)) {
      setMessage('You already guessed that!');
      setTimeout(() => setMessage(''), 2000);
      return;
    }

    if (anagramsLeft.includes(guess)) {
      setScore(prevScore => prevScore + 1);
      setCorrectAnswers([...correctAnswers, guess]);
      setAnagramsLeft(prevAnagrams => prevAnagrams.filter(word => word !== guess));
      setInputValue('');
      setMessage('Correct answer!');
      setTimeout(() => setMessage(''), 2000);
    } else {
      setMessage('Incorrect answer. Try again.');
      setTimeout(() => setMessage(''), 2000);
    }
  };

  useEffect(() => {
    if (anagramsLeft.length === 0 && gameStarted) {
      startNewRound(wordLength);
    }
  }, [anagramsLeft, gameStarted, wordLength]);

  return (
    <Container className="py-5">
      {!gameOver && gameStarted && (
        <div>
          <h2 className="text-center mb-4">Anagram Hunt - Play Page</h2>
          <p className="text-center">Time Left: {timeLeft} seconds</p>
          <h3 className="text-center">Current Word: {currentWord}</h3>
          <p className="text-center">Anagrams left: {anagramsLeft.length}</p>
          <p className="text-center">Score: {score}</p>

          <Form onSubmit={handleSubmit} className="text-center">
            <Form.Group controlId="anagramInput">
              <Form.Label>Type an anagram:</Form.Label>
              <Form.Control
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
              />
            </Form.Group>
            <Button variant="primary" type="submit">Submit</Button>
          </Form>

          {message && <Alert variant="info" className="mt-3">{message}</Alert>}

          <h4 className="mt-4">Guessed Anagrams:</h4>
          <ul>
            {correctAnswers.map((word, index) => (
              <li key={index}>{word}</li>
            ))}
          </ul>
        </div>
      )}

      {gameOver && (
        <div className="text-center mt-4">
          <h2>Game Over!</h2>
          <p>Your final score is: {score}</p>
          <Button variant="primary" onClick={() => navigate(`/endpage?score=${score}`)}>End Game</Button>
        </div>
      )}
    </Container>
  );
}

export default PlayPage;
