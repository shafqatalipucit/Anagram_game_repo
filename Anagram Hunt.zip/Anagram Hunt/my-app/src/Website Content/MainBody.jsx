import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col, Button } from 'react-bootstrap';

function MainBody() {
  return (
    <Container className="py-5">
      <Row className="justify-content-center">
        <Col lg={8} className="text-center">
          <div className="mb-4 pb-3">
            <h2 className="text-primary">Inspiring Quotes</h2>
            <p className="font-italic text-muted mb-3">"EXAMPLE CONTENT FOR QUOTE, THIS WILL BE SET VIA JAVASCRIPT LATER"</p>
            <p className="font-weight-bold mb-0">— EXAMPLE AUTHOR</p>
          </div>
        </Col>
      </Row>

      <Row className="justify-content-center">
        <Col md={6} className="mb-4">
          <div className=" p-4 rounded text-center h-100">
            <h2 className="mb-3">Anagram Hunter</h2>
            <p className="text-muted mb-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequat
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequat.</p>
            <Button variant="primary" href="/games/anagram-hunter">Play Now</Button>
          </div>
        </Col>
        <Col md={6} className="mb-4">
          <div className=" p-4 rounded text-center h-100">
            <h2 className="mb-3">Math Facts Practice</h2>
            <p className="text-muted mb-3">Lorem ipsum dolor sit aLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem , consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatLorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit, lorem eget aliquam consequatmet, consectetur adipiscing elit. Vestibulum eget erat eget odio lacinia.</p>
            <Button variant="primary" href="/games/math-facts">Play Now</Button>
          </div>
        </Col>
      </Row>


    </Container>
  );
}

export default MainBody;
