import React from 'react'
import Header from './Header';
import Footer from './Footer';
import AboutContent from './AboutContent';

function About() {
  return (
    <div>
    <Header/>
    <AboutContent/>
    <Footer/>
    </div>
  )
}

export default About;
