import React from 'react';
import { Container, Button } from 'react-bootstrap';
import { useNavigate, useLocation } from 'react-router-dom';

function EndPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const score = queryParams.get('score');

  return (
    <Container className="py-5 text-center">
      <h1>Anagram Hunt</h1>
      <h2>Time's Up!</h2>
      <p>You Got</p>
      <h1>{score}</h1>
      <p>Anagrams</p>
      <Button variant="primary" className="mt-3" onClick={() => navigate('/playpage')}>
        Play Again
      </Button>
      <Button variant="secondary" className="mt-2" onClick={() => navigate('/startpage')}>
        Back to Start Screen
      </Button>
    </Container>
  );
}

export default EndPage;
