import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope } from '@fortawesome/free-solid-svg-icons'; 
import { faInstagram, faTwitter, faFacebook } from '@fortawesome/free-brands-svg-icons'; 
function Footer() {
    return (
        <div>
            <footer className="bg-light text-center py-5">
                <div className="container">
                    <div className="footer-social">
                        <a href="/contact-us" className="mx-2"><FontAwesomeIcon icon={faEnvelope} /></a>
                        <a href="https://instagram.com" className="mx-2"><FontAwesomeIcon icon={faInstagram} /></a>
                        <a href="https://twitter.com" className="mx-2"><FontAwesomeIcon icon={faTwitter} /></a>
                        <a href="https://facebook.com" className="mx-2"><FontAwesomeIcon icon={faFacebook} /></a>
                    </div>
                    <p className="m-0 text-muted">© 2024 Play2Learn</p>
                </div>
            </footer>
        </div>
    );
}

export default Footer;
