import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Contact = () => {

  const submitForm = (event) => {
    event.preventDefault();
    console.log('Form submitted');
 
  };

  return (
    <div className="container mt-5">
      <div className="card">
        <div className="card-header">
          <h1>Contact Us</h1>
        </div>
        <div className="card-body">
          <form id="contactForm" onSubmit={submitForm}>
            <div className="form-group">
              <label htmlFor="email">Your email:</label>
              <input type="email" className="form-control" id="email" name="email" required />
            </div>

            <div className="form-group">
              <label htmlFor="subject">Subject:</label>
              <input type="text" className="form-control" id="subject" name="subject" required />
            </div>

            <div className="form-group">
              <label htmlFor="message">Message:</label>
              <textarea className="form-control" id="message" name="message" rows="4" required></textarea>
            </div>

            <div className="form-group text-right">
              <button type="submit" className="btn btn-primary">SEND</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
